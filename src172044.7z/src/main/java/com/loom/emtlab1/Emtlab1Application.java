package com.loom.emtlab1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Emtlab1Application {

    public static void main(String[] args) {
        SpringApplication.run(Emtlab1Application.class, args);
    }

}
